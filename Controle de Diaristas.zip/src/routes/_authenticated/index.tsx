import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import { z } from "zod";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription } from "@/components/ui/sheet";
import { Checkbox } from "@/components/ui/checkbox";
import { Textarea } from "@/components/ui/textarea";
import { Search, UserPlus, Trash2, Users, Save } from "lucide-react";
import { toast } from "sonner";

const searchSchema = z.object({
  status: z.enum(["Ativo", "Afastado", "Bloqueado"]).optional(),
});

export const Route = createFileRoute("/_authenticated/")({
  validateSearch: searchSchema,
  head: () => ({
    meta: [
      { title: "Diaristas — Gestão" },
      { name: "description", content: "Cadastro, busca e controle dos seus diaristas." },
    ],
  }),
  component: HomePage,
});

type Status = "Ativo" | "Afastado" | "Bloqueado";
type Turno = "Manhã" | "Tarde" | "Noite" | "Integral";

interface Uniforme {
  bota?: { tamanho?: string; entregue?: boolean; autorizado_levar?: boolean };
  colete?: { entregue?: boolean; autorizado_levar?: boolean };
}

interface Diarista {
  id: string;
  nome: string;
  cpf: string;
  endereco: string;
  localidade: string;
  lider: string;
  turno: Turno;
  telefone: string;
  email: string;
  status: Status;
  foto: string | null;
  uniforme: Uniforme;
}

const empty = {
  nome: "", cpf: "", endereco: "", localidade: "", lider: "",
  turno: "Manhã" as Turno, telefone: "", email: "",
  status: "Ativo" as Status, foto: "", uniforme: {} as Uniforme,
};

function maskCPF(v: string) {
  return v.replace(/\D/g, "").slice(0, 11)
    .replace(/(\d{3})(\d)/, "$1.$2")
    .replace(/(\d{3})(\d)/, "$1.$2")
    .replace(/(\d{3})(\d{1,2})$/, "$1-$2");
}
function maskTel(v: string) {
  const d = v.replace(/\D/g, "").slice(0, 11);
  if (d.length <= 10) return d.replace(/(\d{2})(\d{4})(\d{0,4})/, "($1) $2-$3").trim();
  return d.replace(/(\d{2})(\d{5})(\d{0,4})/, "($1) $2-$3").trim();
}
function initials(name: string) {
  return name.trim().split(/\s+/).slice(0, 2).map(p => p[0]?.toUpperCase() ?? "").join("");
}
function statusVariant(s: Status): "default" | "secondary" | "destructive" | "outline" {
  if (s === "Ativo") return "default";
  if (s === "Afastado") return "secondary";
  return "destructive";
}

function HomePage() {
  const search = Route.useSearch();
  const navigate = useNavigate();
  const [items, setItems] = useState<Diarista[]>([]);
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState("");
  const [tab, setTab] = useState("lista");
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [form, setForm] = useState(empty);
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => { load(); }, []);

  async function load() {
    setLoading(true);
    const { data, error } = await supabase.from("diaristas").select("*").order("nome");
    setLoading(false);
    if (error) return toast.error(error.message);
    setItems((data ?? []) as unknown as Diarista[]);
  }

  const filtered = useMemo(() => {
    let list = items;
    if (search.status) list = list.filter(i => i.status === search.status);
    const q = query.trim().toLowerCase();
    if (q) list = list.filter(i => i.nome.toLowerCase().includes(q) || i.cpf.includes(q));
    return list;
  }, [items, query, search.status]);

  const selected = useMemo(() => items.find(i => i.id === selectedId) ?? null, [items, selectedId]);

  const stats = useMemo(() => ({
    total: items.length,
    ativos: items.filter(i => i.status === "Ativo").length,
    afastados: items.filter(i => i.status === "Afastado").length,
    bloqueados: items.filter(i => i.status === "Bloqueado").length,
  }), [items]);

  function goStatus(s?: Status) {
    navigate({ to: "/", search: s ? { status: s } : {} });
    setTab("lista");
  }

  async function handleFoto(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 2 * 1024 * 1024) return toast.error("Foto deve ter no máximo 2MB");
    const reader = new FileReader();
    reader.onload = () => setForm(f => ({ ...f, foto: reader.result as string }));
    reader.readAsDataURL(file);
  }

  async function add(e: React.FormEvent) {
    e.preventDefault();
    if (!form.nome.trim()) return toast.error("Nome é obrigatório");
    const { error } = await supabase.from("diaristas").insert({
      ...form, foto: form.foto || null, uniforme: form.uniforme as never,
    });
    if (error) return toast.error(error.message);
    toast.success("Diarista cadastrada");
    setForm(empty);
    if (fileRef.current) fileRef.current.value = "";
    setTab("lista");
    load();
  }

  async function remove(id: string) {
    if (!confirm("Remover este diarista?")) return;
    const { error } = await supabase.from("diaristas").delete().eq("id", id);
    if (error) return toast.error(error.message);
    setSelectedId(null);
    load();
    toast.success("Removido");
  }

  async function updateSelected(patch: Partial<Diarista>): Promise<void> {
    if (!selected) return;
    const { error } = await supabase.from("diaristas").update(patch as never).eq("id", selected.id);
    if (error) { toast.error(error.message); return; }
    setItems(prev => prev.map(i => i.id === selected.id ? { ...i, ...patch } : i));
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b bg-card">
        <div className="container mx-auto flex items-center gap-3 px-4 py-4">
          <div className="rounded-lg bg-primary/10 p-2 text-primary">
            <Users className="h-6 w-6" />
          </div>
          <div className="flex-1">
            <h1 className="text-xl font-semibold tracking-tight">Gestão de Diaristas</h1>
          </div>
        </div>
      </header>


      <main className="container mx-auto px-4 py-6">
        <div className="mb-6 grid grid-cols-2 gap-3 md:grid-cols-4">
          <StatCard label="Total" value={stats.total} active={!search.status} onClick={() => goStatus(undefined)} />
          <StatCard label="Ativos" value={stats.ativos} active={search.status === "Ativo"} onClick={() => goStatus("Ativo")} />
          <StatCard label="Afastados" value={stats.afastados} active={search.status === "Afastado"} onClick={() => goStatus("Afastado")} />
          <StatCard label="Bloqueados" value={stats.bloqueados} active={search.status === "Bloqueado"} onClick={() => goStatus("Bloqueado")} />
        </div>

        <Tabs value={tab} onValueChange={setTab}>
          <TabsList>
            <TabsTrigger value="lista">Diaristas</TabsTrigger>
            <TabsTrigger value="cadastrar">Cadastrar</TabsTrigger>
          </TabsList>

          <TabsContent value="lista" className="mt-4">
            <Card>
              <CardHeader className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                <div>
                  <CardTitle>
                    {search.status ? `Status: ${search.status}` : "Todas as Diaristas"}
                  </CardTitle>
                  <CardDescription>Clique em uma linha para ver todos os dados</CardDescription>
                </div>
                <div className="relative w-full sm:w-80">
                  <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input placeholder="Pesquisar por nome ou CPF..." value={query} onChange={e => setQuery(e.target.value)} className="pl-9" />
                </div>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Nome</TableHead>
                        <TableHead>CPF</TableHead>
                        <TableHead>Turno</TableHead>
                        <TableHead>Status</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {loading && (
                        <TableRow><TableCell colSpan={4} className="py-10 text-center text-muted-foreground">Carregando...</TableCell></TableRow>
                      )}
                      {!loading && filtered.length === 0 && (
                        <TableRow><TableCell colSpan={4} className="py-10 text-center text-muted-foreground">Nenhum diarista encontrado.</TableCell></TableRow>
                      )}
                      {filtered.map(c => (
                        <TableRow key={c.id} className="cursor-pointer hover:bg-muted/50" onClick={() => setSelectedId(c.id)}>
                          <TableCell className="font-medium flex items-center gap-2">
                            <Avatar className="h-8 w-8">
                              <AvatarImage src={c.foto ?? undefined} alt={c.nome} />
                              <AvatarFallback className="text-xs">{initials(c.nome)}</AvatarFallback>
                            </Avatar>
                            {c.nome}
                          </TableCell>
                          <TableCell>{c.cpf || "—"}</TableCell>
                          <TableCell>{c.turno}</TableCell>
                          <TableCell><Badge variant={statusVariant(c.status)}>{c.status}</Badge></TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="cadastrar" className="mt-4">
            <Card>
              <CardHeader>
                <CardTitle>Nova Diarista</CardTitle>
                <CardDescription>Preencha os dados abaixo</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={add} className="grid gap-4 sm:grid-cols-2">
                  <div className="sm:col-span-2 flex items-center gap-4">
                    <Avatar className="h-20 w-20">
                      <AvatarImage src={form.foto} alt="preview" />
                      <AvatarFallback>{initials(form.nome) || "?"}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <Label htmlFor="foto">Foto</Label>
                      <Input id="foto" ref={fileRef} type="file" accept="image/*" onChange={handleFoto} className="mt-1" />
                    </div>
                  </div>
                  <Field label="Nome" id="nome"><Input id="nome" value={form.nome} onChange={e => setForm({ ...form, nome: e.target.value })} maxLength={100} required /></Field>
                  <Field label="CPF" id="cpf"><Input id="cpf" value={form.cpf} onChange={e => setForm({ ...form, cpf: maskCPF(e.target.value) })} placeholder="000.000.000-00" /></Field>
                  <Field label="Endereço" id="end" className="sm:col-span-2"><Textarea id="end" value={form.endereco} onChange={e => setForm({ ...form, endereco: e.target.value })} rows={2} /></Field>
                  <Field label="SC / Localidade" id="loc"><Input id="loc" value={form.localidade} onChange={e => setForm({ ...form, localidade: e.target.value })} /></Field>
                  <Field label="Líder" id="lider"><Input id="lider" value={form.lider} onChange={e => setForm({ ...form, lider: e.target.value })} /></Field>
                  <Field label="Turno" id="turno">
                    <Select value={form.turno} onValueChange={v => setForm({ ...form, turno: v as Turno })}>
                      <SelectTrigger id="turno"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Manhã">Manhã</SelectItem>
                        <SelectItem value="Tarde">Tarde</SelectItem>
                        <SelectItem value="Noite">Noite</SelectItem>
                        <SelectItem value="Integral">Integral</SelectItem>
                      </SelectContent>
                    </Select>
                  </Field>
                  <Field label="Telefone" id="tel"><Input id="tel" value={form.telefone} onChange={e => setForm({ ...form, telefone: maskTel(e.target.value) })} placeholder="(00) 00000-0000" /></Field>
                  <Field label="Email" id="email"><Input id="email" type="email" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} /></Field>
                  <Field label="Status" id="status">
                    <Select value={form.status} onValueChange={v => setForm({ ...form, status: v as Status })}>
                      <SelectTrigger id="status"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Ativo">Ativo</SelectItem>
                        <SelectItem value="Afastado">Afastado</SelectItem>
                        <SelectItem value="Bloqueado">Bloqueado</SelectItem>
                      </SelectContent>
                    </Select>
                  </Field>
                  <div className="sm:col-span-2 flex justify-end gap-2">
                    <Button type="button" variant="outline" onClick={() => setForm(empty)}>Limpar</Button>
                    <Button type="submit"><UserPlus className="mr-2 h-4 w-4" />Cadastrar</Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>

      <Sheet open={!!selected} onOpenChange={(o) => !o && setSelectedId(null)}>
        <SheetContent className="w-full sm:max-w-lg overflow-y-auto">
          {selected && <DetailPanel key={selected.id} d={selected} onSave={updateSelected} onRemove={() => remove(selected.id)} />}
        </SheetContent>
      </Sheet>
    </div>
  );
}

function StatCard({ label, value, active, onClick }: { label: string; value: number; active: boolean; onClick: () => void }) {
  return (
    <button onClick={onClick} className={`text-left rounded-lg border bg-card p-4 transition-colors hover:bg-accent ${active ? "ring-2 ring-primary" : ""}`}>
      <div className="text-xs uppercase tracking-wide text-muted-foreground">{label}</div>
      <div className="mt-1 text-2xl font-semibold">{value}</div>
    </button>
  );
}

function Field({ label, id, className = "", children }: { label: string; id: string; className?: string; children: React.ReactNode }) {
  return (
    <div className={`space-y-1.5 ${className}`}>
      <Label htmlFor={id}>{label}</Label>
      {children}
    </div>
  );
}

function DetailPanel({ d, onSave, onRemove }: { d: Diarista; onSave: (p: Partial<Diarista>) => Promise<void>; onRemove: () => void }) {
  const [local, setLocal] = useState<Diarista>(d);
  const [saving, setSaving] = useState(false);

  useEffect(() => { setLocal(d); }, [d.id]);

  function set<K extends keyof Diarista>(k: K, v: Diarista[K]) { setLocal(p => ({ ...p, [k]: v })); }
  function setUni(patch: Uniforme) { setLocal(p => ({ ...p, uniforme: { ...p.uniforme, ...patch } })); }

  async function save() {
    setSaving(true);
    await onSave({
      nome: local.nome, cpf: local.cpf, endereco: local.endereco, localidade: local.localidade,
      lider: local.lider, turno: local.turno, telefone: local.telefone, email: local.email,
      status: local.status, uniforme: local.uniforme,
    });
    setSaving(false);
    toast.success("Salvo");
  }

  const bota = local.uniforme?.bota ?? {};
  const colete = local.uniforme?.colete ?? {};

  return (
    <>
      <SheetHeader>
        <div className="flex items-center gap-3">
          <Avatar className="h-16 w-16">
            <AvatarImage src={local.foto ?? undefined} alt={local.nome} />
            <AvatarFallback>{initials(local.nome)}</AvatarFallback>
          </Avatar>
          <div className="flex-1">
            <SheetTitle>{local.nome}</SheetTitle>
            <SheetDescription>
              <Badge variant={statusVariant(local.status)}>{local.status}</Badge>
            </SheetDescription>
          </div>
        </div>
      </SheetHeader>

      <div className="space-y-4 py-4">
        <Field label="Nome" id="d-nome"><Input id="d-nome" value={local.nome} onChange={e => set("nome", e.target.value)} /></Field>
        <Field label="Endereço" id="d-end"><Textarea id="d-end" value={local.endereco} onChange={e => set("endereco", e.target.value)} rows={2} /></Field>
        <Field label="CPF" id="d-cpf"><Input id="d-cpf" value={local.cpf} onChange={e => set("cpf", maskCPF(e.target.value))} /></Field>
        <Field label="SC / Localidade" id="d-loc"><Input id="d-loc" value={local.localidade} onChange={e => set("localidade", e.target.value)} /></Field>
        <Field label="Líder" id="d-lider"><Input id="d-lider" value={local.lider} onChange={e => set("lider", e.target.value)} /></Field>
        <Field label="Turno" id="d-turno">
          <Select value={local.turno} onValueChange={v => set("turno", v as Turno)}>
            <SelectTrigger id="d-turno"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="Manhã">Manhã</SelectItem>
              <SelectItem value="Tarde">Tarde</SelectItem>
              <SelectItem value="Noite">Noite</SelectItem>
              <SelectItem value="Integral">Integral</SelectItem>
            </SelectContent>
          </Select>
        </Field>
        <Field label="Telefone" id="d-tel"><Input id="d-tel" value={local.telefone} onChange={e => set("telefone", maskTel(e.target.value))} /></Field>
        <Field label="Email" id="d-email"><Input id="d-email" type="email" value={local.email} onChange={e => set("email", e.target.value)} /></Field>
        <Field label="Status" id="d-status">
          <Select value={local.status} onValueChange={v => set("status", v as Status)}>
            <SelectTrigger id="d-status"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="Ativo">Ativo</SelectItem>
              <SelectItem value="Afastado">Afastado</SelectItem>
              <SelectItem value="Bloqueado">Bloqueado</SelectItem>
            </SelectContent>
          </Select>
        </Field>

        <div className="rounded-lg border p-3 space-y-3">
          <div className="font-medium">Controle de Uniforme</div>

          <div className="space-y-2">
            <div className="text-sm font-medium">Bota</div>
            <div className="grid grid-cols-3 gap-2 items-end">
              <Field label="Tamanho" id="bt-tam">
                <Input id="bt-tam" value={bota.tamanho ?? ""} onChange={e => setUni({ bota: { ...bota, tamanho: e.target.value } })} placeholder="Ex: 42" />
              </Field>
              <label className="flex items-center gap-2 text-sm pb-2">
                <Checkbox checked={!!bota.entregue} onCheckedChange={v => setUni({ bota: { ...bota, entregue: !!v } })} />
                Entregue
              </label>
              <label className="flex items-center gap-2 text-sm pb-2">
                <Checkbox checked={!!bota.autorizado_levar} onCheckedChange={v => setUni({ bota: { ...bota, autorizado_levar: !!v } })} />
                Autorizado a levar
              </label>
            </div>
          </div>

          <div className="space-y-2">
            <div className="text-sm font-medium">Colete</div>
            <div className="grid grid-cols-2 gap-2">
              <label className="flex items-center gap-2 text-sm">
                <Checkbox checked={!!colete.entregue} onCheckedChange={v => setUni({ colete: { ...colete, entregue: !!v } })} />
                Entregue
              </label>
              <label className="flex items-center gap-2 text-sm">
                <Checkbox checked={!!colete.autorizado_levar} onCheckedChange={v => setUni({ colete: { ...colete, autorizado_levar: !!v } })} />
                Autorizado a levar
              </label>
            </div>
          </div>
        </div>

        <div className="flex justify-between gap-2 pt-2">
          <Button variant="destructive" onClick={onRemove}><Trash2 className="h-4 w-4 mr-1" />Remover</Button>
          <Button onClick={save} disabled={saving}><Save className="h-4 w-4 mr-1" />{saving ? "Salvando..." : "Salvar"}</Button>
        </div>
      </div>
    </>
  );
}
